Basic-Banking-System
An implementation of Basic Banking System using HTML-CSS-JS.

So, in this task I have developed a Basic Banking System which stores the list of customers and allows us to transfer money among the available customers while maintaining a transaction record. I've used HTML, CSS and JavaScript in order to implement this.

Link to LinkedIn Post(With Explanation Video)
